package com.archon.client.mods

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.runtime.mutableStateListOf
import androidx.core.content.FileProvider
import com.archon.client.minecraft.MinecraftLauncher
import java.io.File

/** Отдаёт файл самому Minecraft: он сам импортирует .mcpack / .mcaddon / .mcworld. */
object ModInstaller {
    fun install(context: Context, file: File): Boolean {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

        fun build(withType: Boolean) = Intent(Intent.ACTION_VIEW).apply {
            if (withType) setDataAndType(uri, "application/octet-stream") else data = uri
            setPackage(MinecraftLauncher.PACKAGE)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        return try {
            context.startActivity(build(true))
            true
        } catch (e: ActivityNotFoundException) {
            try {
                context.startActivity(build(false))
                true
            } catch (e2: Exception) {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}

/** Очередь: Minecraft принимает файлы по одному, поэтому ставим их по очереди. */
object InstallQueue {
    val pending = mutableStateListOf<File>()

    fun start(context: Context, files: List<File>) {
        pending.clear()
        pending.addAll(files)
        next(context)
    }

    fun next(context: Context) {
        if (pending.isEmpty()) return
        val file = pending.removeAt(0)
        if (!ModInstaller.install(context, file)) {
            pending.clear()
            Toast.makeText(context, "Minecraft не смог открыть файл: ${file.name}", Toast.LENGTH_LONG).show()
        }
    }

    fun cancel() = pending.clear()
}
