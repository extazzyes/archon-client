package com.archon.client.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object AppSettings {
    val accents = listOf(
        "Фиолетовый" to Color(0xFF8B5CF6),
        "Синий" to Color(0xFF3B82F6),
        "Зелёный" to Color(0xFF22C55E),
        "Красный" to Color(0xFFEF4444),
        "Оранжевый" to Color(0xFFF59E0B),
        "Розовый" to Color(0xFFEC4899),
    )

    private const val PREFS = "archon"

    var accentIndex by mutableIntStateOf(0)
        private set
    var amoled by mutableStateOf(false)
        private set
    var confirmDelete by mutableStateOf(true)
        private set
    var profileColor by mutableStateOf(true)
        private set
    var accentOverride by mutableStateOf<Color?>(null)
        private set

    val accent: Color get() = accents[accentIndex].second

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context) {
        val p = prefs(context)
        accentIndex = p.getInt("accent", 0).coerceIn(accents.indices)
        amoled = p.getBoolean("amoled", false)
        confirmDelete = p.getBoolean("confirm_delete", true)
        profileColor = p.getBoolean("profile_color", true)
    }

    fun setAccent(context: Context, index: Int) {
        accentIndex = index
        prefs(context).edit().putInt("accent", index).apply()
    }

    fun setAmoled(context: Context, value: Boolean) {
        amoled = value
        prefs(context).edit().putBoolean("amoled", value).apply()
    }

    fun setConfirmDelete(context: Context, value: Boolean) {
        confirmDelete = value
        prefs(context).edit().putBoolean("confirm_delete", value).apply()
    }

    fun setProfileColor(context: Context, value: Boolean) {
        profileColor = value
        prefs(context).edit().putBoolean("profile_color", value).apply()
    }

    fun setOverride(color: Color?) {
        accentOverride = color
    }
}
