package com.archon.client.mods

import android.content.Context
import java.io.File
import java.util.Collections
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Minecraft принимает за раз только один файл, но один .mcaddon может содержать
 * сколько угодно паков. Поэтому выбранные .mcpack / .mcaddon склеиваем в один .mcaddon.
 * Миры и шаблоны (.mcworld / .mctemplate) склеить нельзя, они ставятся по очереди.
 */
object ModBundler {
    fun isPack(f: File) = f.extension.lowercase() in setOf("mcpack", "mcaddon")

    /** Возвращает список файлов, которые нужно по очереди отдать Minecraft. */
    fun plan(context: Context, chosen: List<File>): List<File> {
        val packs = chosen.filter { isPack(it) }
        val others = chosen.filter { !isPack(it) }
        val first = when (packs.size) {
            0 -> emptyList()
            1 -> packs
            else -> listOf(bundle(context, packs))
        }
        return first + others
    }

    private fun bundle(context: Context, packs: List<File>): File {
        val dir = File(context.filesDir, "bundle")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "Archon-${packs.size}-addons.mcaddon")
        val used = mutableSetOf<String>()
        ZipOutputStream(out.outputStream().buffered()).use { zip ->
            packs.forEach { addPack(zip, it, used) }
        }
        return out
    }

    private fun addPack(zip: ZipOutputStream, file: File, used: MutableSet<String>) {
        ZipFile(file).use { zf ->
            val entries = Collections.list(zf.entries()).filter { !it.name.startsWith("__MACOSX") }
            val hasRootManifest = entries.any { it.name == "manifest.json" }

            // Обычный .mcpack: manifest.json лежит в корне, кладём всё в отдельную папку
            val prefix: String? =
                if (file.extension.equals("mcpack", true) && hasRootManifest) {
                    uniqueName(file.nameWithoutExtension.replace(Regex("[^A-Za-z0-9._-]"), "_"), used)
                } else null

            val renamed = mutableMapOf<String, String>()
            for (e in entries) {
                val newName = if (prefix != null) {
                    "$prefix/${e.name}"
                } else {
                    val top = e.name.substringBefore('/')
                    val mapped = renamed.getOrPut(top) { uniqueName(top, used) }
                    if (e.name.contains('/')) mapped + "/" + e.name.substringAfter('/') else mapped
                }
                try {
                    zip.putNextEntry(ZipEntry(newName))
                    if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zip) }
                    zip.closeEntry()
                } catch (ex: ZipException) {
                    // дубликат записи, пропускаем
                }
            }
        }
    }

    private fun uniqueName(name: String, used: MutableSet<String>): String {
        if (used.add(name)) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 2
        while (true) {
            val candidate = "${base}_$n$ext"
            if (used.add(candidate)) return candidate
            n++
        }
    }
}
