package com.archon.client.ui

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.archon.client.minecraft.MinecraftLauncher

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Главная", Icons.Filled.Home),
    Addons("Аддоны", Icons.Filled.Add),
    Worlds("Миры", Icons.Filled.Star),
    Skins("Скины", Icons.Filled.Person),
}

@Composable
fun ArchonApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.Home) }
    var status by remember { mutableStateOf(MinecraftLauncher.getStatus(context)) }

    // Обновляем статус, когда возвращаемся в приложение (например, после установки игры)
    val lifecycle = (context as ComponentActivity).lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                status = MinecraftLauncher.getStatus(context)
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Tab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                    )
                }
            }
        },
    ) { padding ->
        val modifier = Modifier.padding(padding)
        when (tab) {
            Tab.Home -> HomeScreen(
                status = status,
                onPlay = {
                    if (!MinecraftLauncher.launch(context)) {
                        Toast.makeText(context, "Не удалось запустить Minecraft", Toast.LENGTH_SHORT).show()
                    }
                },
                onInstall = { MinecraftLauncher.openStore(context) },
                modifier = modifier,
            )
            Tab.Addons -> ModsScreen(modifier)
            Tab.Worlds -> ComingSoonScreen("Миры", "Бэкап и восстановление миров", modifier)
            Tab.Skins -> ComingSoonScreen("Скины", "Управление скинами", modifier)
        }
    }
}

@Composable
private fun ComingSoonScreen(title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            text,
            modifier = Modifier.padding(top = 8.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Text("Скоро", modifier = Modifier.padding(top = 16.dp), color = Violet, fontWeight = FontWeight.Medium)
    }
}
