package com.archon.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.minecraft.McStatus
import com.archon.client.minecraft.MinecraftLauncher

@Composable
fun HomeScreen(
    status: McStatus,
    onPlay: () -> Unit,
    onInstall: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero()
        Column(
            Modifier.padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            MinecraftCard(status)
            when (status) {
                McStatus.NotInstalled -> ArchonButton("УСТАНОВИТЬ MINECRAFT", showIcon = false, onClick = onInstall)
                is McStatus.Installed -> ArchonButton("ИГРАТЬ", showIcon = true, onClick = onPlay)
            }
            if (status is McStatus.Installed && !status.supported) {
                Text(
                    "Эта версия новее ${MinecraftLauncher.MAX_MAJOR}.${MinecraftLauncher.MAX_MINOR}. Часть функций лаунчера может не работать.",
                    color = Warn,
                    fontSize = 13.sp,
                )
            }
        }
    }
}

@Composable
private fun Hero() {
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF3B1D7A), Bg)))
            .padding(start = 24.dp, end = 24.dp, top = 56.dp, bottom = 36.dp),
    ) {
        Column {
            Text("ARCHON", fontSize = 44.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp, color = Color.White)
            Text("CLIENT", fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 12.sp, color = Violet)
            Text(
                "Лаунчер для Minecraft Bedrock",
                modifier = Modifier.padding(top = 12.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MinecraftCard(status: McStatus) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Minecraft Bedrock", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            when (status) {
                McStatus.NotInstalled -> {
                    Text("Игра не найдена на устройстве", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Badge("Не установлена", Warn)
                }
                is McStatus.Installed -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Версия", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(status.versionName, fontWeight = FontWeight.Bold)
                    }
                    if (status.supported) Badge("Поддерживается", Ok) else Badge("Не проверена", Warn)
                }
            }
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ArchonButton(text: String, showIcon: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().height(60.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showIcon) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
            }
            Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}
