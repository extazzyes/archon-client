package com.archon.client.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.mods.CatalogItem
import com.archon.client.mods.InstallQueue
import com.archon.client.mods.ModsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.material3.Tab as MTab

private sealed interface CatalogState {
    data object Loading : CatalogState
    data class Error(val message: String) : CatalogState
    data class Ready(val items: List<CatalogItem>) : CatalogState
}

@Composable
fun ModsScreen(modifier: Modifier = Modifier) {
    var section by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }

    Column(modifier.fillMaxSize()) {
        Text(
            "Аддоны",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 8.dp),
        )
        QueueBanner()
        TabRow(selectedTabIndex = section, containerColor = Color.Transparent) {
            MTab(selected = section == 0, onClick = { section = 0 }, text = { Text("Библиотека") })
            MTab(selected = section == 1, onClick = { section = 1 }, text = { Text("Каталог") })
        }
        if (section == 0) {
            LibraryTab(Modifier.weight(1f), refresh) { refresh++ }
        } else {
            CatalogTab(Modifier.weight(1f), refresh) { refresh++ }
        }
    }
}

@Composable
private fun QueueBanner() {
    val context = LocalContext.current
    val left = InstallQueue.pending.size
    if (left > 0) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Очередь установки: осталось $left", fontWeight = FontWeight.Bold)
                Text(
                    "Дождись, пока Minecraft закончит импорт, вернись в Archon и нажми «Следующий».",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { InstallQueue.next(context) }) { Text("Следующий") }
                    TextButton(onClick = { InstallQueue.cancel() }) { Text("Отмена") }
                }
            }
        }
    }
}

@Composable
private fun LibraryTab(modifier: Modifier, refresh: Int, onChanged: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val files = remember(refresh) { ModsRepository.list(context) }
    val selected = remember { mutableStateListOf<String>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            val (added, skipped) = withContext(Dispatchers.IO) {
                var a = 0
                var s = 0
                uris.forEach { uri ->
                    if (runCatching { ModsRepository.importFromUri(context, uri) }.getOrDefault(false)) a++ else s++
                }
                a to s
            }
            val msg = if (skipped == 0) "Добавлено: $added"
            else "Добавлено: $added, пропущено: $skipped (нужны .mcpack, .mcaddon, .mcworld, .mctemplate)"
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            onChanged()
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(14.dp)) {
                Text("+ Добавить файлы")
            }
        }
        if (files.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Здесь пока пусто. Добавь файлы с телефона или скачай их из каталога.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(files, key = { it.name }) { file ->
                    ModRow(
                        file = file,
                        checked = file.name in selected,
                        onCheck = { on -> if (on) selected.add(file.name) else selected.remove(file.name) },
                        onInstall = { InstallQueue.start(context, listOf(file)) },
                        onDelete = {
                            file.delete()
                            selected.remove(file.name)
                            onChanged()
                        },
                    )
                }
            }
        }
        if (selected.isNotEmpty()) {
            Button(
                onClick = {
                    val chosen = files.filter { it.name in selected }
                    selected.clear()
                    InstallQueue.start(context, chosen)
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            ) { Text("Установить выбранные (${selected.size})") }
        }
    }
}

@Composable
private fun ModRow(
    file: File,
    checked: Boolean,
    onCheck: (Boolean) -> Unit,
    onInstall: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(start = 4.dp, end = 8.dp, top = 8.dp, bottom = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = checked, onCheckedChange = onCheck)
                Column(Modifier.weight(1f)) {
                    Text(
                        file.nameWithoutExtension,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "${file.extension.uppercase()} · ${formatSize(file.length())}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onInstall) { Text("Установить") }
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Удалить") }
            }
        }
    }
}

@Composable
private fun CatalogTab(modifier: Modifier, refresh: Int, onChanged: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(ModsRepository.getCatalogUrl(context)) }
    var reload by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf<CatalogState>(CatalogState.Loading) }
    var showDialog by remember { mutableStateOf(false) }
    val busy = remember { mutableStateListOf<String>() }
    val have = remember(refresh) { ModsRepository.list(context).map { it.name }.toSet() }

    LaunchedEffect(url, reload) {
        state = CatalogState.Loading
        state = withContext(Dispatchers.IO) {
            try {
                CatalogState.Ready(ModsRepository.fetchCatalog(url))
            } catch (e: Exception) {
                CatalogState.Error(e.message ?: "Не удалось загрузить каталог")
            }
        }
    }

    suspend fun downloadOne(item: CatalogItem) {
        if (item.fileName in busy) return
        busy.add(item.fileName)
        val ok = withContext(Dispatchers.IO) { runCatching { ModsRepository.download(context, item) }.isSuccess }
        busy.remove(item.fileName)
        if (!ok) Toast.makeText(context, "Не удалось скачать: ${item.name}", Toast.LENGTH_LONG).show()
        onChanged()
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            TextButton(onClick = { showDialog = true }) { Text("Источник") }
            TextButton(onClick = { reload++ }) { Text("Обновить") }
        }
        when (val s = state) {
            CatalogState.Loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            is CatalogState.Error -> Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "${s.message}\n\nПроверь интернет и ссылку на каталог (кнопка «Источник»).",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
            is CatalogState.Ready -> {
                if (s.items.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("Каталог пуст", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(s.items, key = { it.fileName }) { item ->
                            CatalogRow(
                                item = item,
                                inLibrary = item.fileName in have,
                                downloading = item.fileName in busy,
                                onDownload = { scope.launch { downloadOne(item) } },
                            )
                        }
                    }
                    val missing = s.items.filter { it.fileName !in have && it.fileName !in busy }
                    if (missing.isNotEmpty()) {
                        Button(
                            onClick = { scope.launch { missing.forEach { downloadOne(it) } } },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                        ) { Text("Скачать всё (${missing.size})") }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var text by remember { mutableStateOf(url) }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Источник каталога") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Ссылка на catalog.json") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = text.trim()
                    if (u.startsWith("https://")) {
                        ModsRepository.setCatalogUrl(context, u)
                        url = u
                        showDialog = false
                    } else {
                        Toast.makeText(context, "Ссылка должна начинаться с https://", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { text = ModsRepository.DEFAULT_CATALOG_URL }) { Text("По умолчанию") }
                    TextButton(onClick = { showDialog = false }) { Text("Отмена") }
                }
            },
        )
    }
}

@Composable
private fun CatalogRow(item: CatalogItem, inLibrary: Boolean, downloading: Boolean, onDownload: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(item.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (item.version.isNotBlank()) {
                    Text(item.version, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (item.description.isNotBlank()) {
                Text(item.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                when {
                    inLibrary -> Chip("В библиотеке", Ok)
                    downloading -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    else -> Button(onClick = onDownload, shape = RoundedCornerShape(12.dp)) { Text("Скачать") }
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun formatSize(bytes: Long): String =
    if (bytes < 1024 * 1024) "${bytes / 1024 + 1} КБ" else "%.1f МБ".format(bytes / 1048576.0)
