package com.archon.client.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.mods.CatalogItem
import com.archon.client.mods.InstallQueue
import com.archon.client.mods.ModBundler
import com.archon.client.mods.ModsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import androidx.compose.material3.Tab as MTab

private sealed interface CatalogState {
    data object Loading : CatalogState
    data class Error(val message: String) : CatalogState
    data class Ready(val items: List<CatalogItem>) : CatalogState
}

private val SelectedBg = Color(0xFF2A2145)

@Composable
fun ModsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var section by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val files = remember(refresh) { ModsRepository.list(context) }
    val busy = remember { mutableStateListOf<String>() }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun downloadOne(item: CatalogItem) {
        if (item.fileName in busy) return
        busy.add(item.fileName)
        val failure: String? = withContext(Dispatchers.IO) {
            try {
                ModsRepository.download(context, item)
                null
            } catch (e: Exception) {
                ModsRepository.friendly(e)
            }
        }
        busy.remove(item.fileName)
        if (failure != null) error = "«${item.name}»: $failure"
        refresh++
    }

    Column(modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)) {
            Text("Аддоны", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "Отметь несколько и поставь в Minecraft за один раз",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        QueueBanner()
        TabRow(selectedTabIndex = section, containerColor = Color.Transparent) {
            MTab(selected = section == 0, onClick = { section = 0 }, text = { Text("Библиотека (${files.size})") })
            MTab(selected = section == 1, onClick = { section = 1 }, text = { Text("Каталог") })
        }
        if (section == 0) {
            LibraryTab(
                modifier = Modifier.weight(1f),
                files = files,
                onChanged = { refresh++ },
                goCatalog = { section = 1 },
            )
        } else {
            CatalogTab(
                modifier = Modifier.weight(1f),
                files = files,
                busy = busy,
                onDownload = { item -> scope.launch { downloadOne(item) } },
                onDownloadAll = { items -> scope.launch { items.forEach { downloadOne(it) } } },
            )
        }
    }

    error?.let { msg ->
        AlertDialog(
            onDismissRequest = { error = null },
            title = { Text("Не удалось скачать") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("Понятно") } },
        )
    }
}

@Composable
private fun QueueBanner() {
    val context = LocalContext.current
    val left = InstallQueue.pending.size
    if (left > 0) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("В очереди ещё файлов: $left", fontWeight = FontWeight.Bold)
                Text(
                    "Миры и шаблоны Minecraft принимает по одному. После импорта вернись в Archon и нажми «Следующий».",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { InstallQueue.next(context) }) { Text("Следующий") }
                    TextButton(onClick = { InstallQueue.cancel() }) { Text("Отмена") }
                }
            }
        }
    }
}

@Composable
private fun LibraryTab(
    modifier: Modifier,
    files: List<File>,
    onChanged: () -> Unit,
    goCatalog: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val selected = remember { mutableStateListOf<String>() }
    var working by remember { mutableStateOf(false) }

    // Если файл удалили, убираем его из выбранных
    LaunchedEffect(files) { selected.removeAll { name -> files.none { it.name == name } } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            val (added, skipped) = withContext(Dispatchers.IO) {
                var a = 0
                var s = 0
                uris.forEach { uri ->
                    if (runCatching { ModsRepository.importFromUri(context, uri) }.getOrDefault(false)) a++ else s++
                }
                a to s
            }
            val msg = if (skipped == 0) "Добавлено: $added"
            else "Добавлено: $added, пропущено: $skipped (нужны .mcpack, .mcaddon, .mcworld, .mctemplate)"
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            onChanged()
        }
    }

    fun installSelected() {
        val chosen = files.filter { it.name in selected }
        if (chosen.isEmpty() || working) return
        working = true
        scope.launch {
            val plan = withContext(Dispatchers.IO) { runCatching { ModBundler.plan(context, chosen) } }
            working = false
            plan.onSuccess { list ->
                val packs = chosen.count { ModBundler.isPack(it) }
                if (packs >= 2) {
                    Toast.makeText(context, "$packs аддонов собраны в один файл. Minecraft поставит их разом", Toast.LENGTH_LONG).show()
                }
                selected.clear()
                InstallQueue.start(context, list)
            }.onFailure {
                Toast.makeText(context, "Не удалось подготовить файлы: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(14.dp)) {
                Text("+ Добавить")
            }
            Spacer(Modifier.weight(1f))
            if (files.isNotEmpty()) {
                val all = selected.size == files.size
                TextButton(onClick = {
                    selected.clear()
                    if (!all) selected.addAll(files.map { it.name })
                }) { Text(if (all) "Снять выбор" else "Выбрать все") }
            }
        }

        if (files.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "Здесь пока пусто",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "Добавь файлы с телефона или скачай их из каталога.",
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Button(onClick = goCatalog, shape = RoundedCornerShape(14.dp)) { Text("Открыть каталог") }
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(files, key = { it.name }) { file ->
                    val checked = file.name in selected
                    LibraryRow(
                        file = file,
                        checked = checked,
                        onToggle = { if (checked) selected.remove(file.name) else selected.add(file.name) },
                        onDelete = {
                            file.delete()
                            selected.remove(file.name)
                            onChanged()
                        },
                    )
                }
            }
        }

        if (selected.isNotEmpty()) {
            Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Button(
                        onClick = { installSelected() },
                        enabled = !working,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            if (working) "Подготовка…" else "Установить в Minecraft (${selected.size})",
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryRow(file: File, checked: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (checked) SelectedBg else MaterialTheme.colorScheme.surface,
        ),
        border = if (checked) BorderStroke(1.dp, Violet) else null,
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onToggle),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Text(
                    file.nameWithoutExtension,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${typeLabel(file)} · ${formatSize(file.length())}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Удалить") }
        }
    }
}

@Composable
private fun CatalogTab(
    modifier: Modifier,
    files: List<File>,
    busy: List<String>,
    onDownload: (CatalogItem) -> Unit,
    onDownloadAll: (List<CatalogItem>) -> Unit,
) {
    val context = LocalContext.current
    var url by remember { mutableStateOf(ModsRepository.getCatalogUrl(context)) }
    var reload by remember { mutableIntStateOf(0) }
    var state by remember { mutableStateOf<CatalogState>(CatalogState.Loading) }
    var showDialog by remember { mutableStateOf(false) }
    val have = files.map { it.name }.toSet()

    LaunchedEffect(url, reload) {
        state = CatalogState.Loading
        state = withContext(Dispatchers.IO) {
            try {
                CatalogState.Ready(ModsRepository.fetchCatalog(url))
            } catch (e: Exception) {
                CatalogState.Error(ModsRepository.friendly(e))
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            TextButton(onClick = { reload++ }) { Text("Обновить") }
            TextButton(onClick = { showDialog = true }) { Text("Источник") }
        }
        when (val s = state) {
            CatalogState.Loading -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            is CatalogState.Error -> Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Каталог не загрузился", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    s.message,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
                Button(onClick = { reload++ }, shape = RoundedCornerShape(14.dp)) { Text("Повторить") }
            }
            is CatalogState.Ready -> {
                if (s.items.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("Каталог пуст", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        Modifier.weight(1f),
                        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(s.items, key = { it.fileName }) { item ->
                            CatalogRow(
                                item = item,
                                inLibrary = item.fileName in have,
                                downloading = item.fileName in busy,
                                onDownload = { onDownload(item) },
                            )
                        }
                    }
                    val missing = s.items.filter { it.fileName !in have && it.fileName !in busy }
                    if (missing.isNotEmpty()) {
                        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
                            Button(
                                onClick = { onDownloadAll(missing) },
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                            ) { Text("Скачать всё (${missing.size})", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var text by remember { mutableStateOf(url) }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Источник каталога") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Ссылка на catalog.json") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = text.trim()
                    if (u.startsWith("https://")) {
                        ModsRepository.setCatalogUrl(context, u)
                        url = u
                        showDialog = false
                    } else {
                        Toast.makeText(context, "Ссылка должна начинаться с https://", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { text = ModsRepository.DEFAULT_CATALOG_URL }) { Text("По умолчанию") }
                    TextButton(onClick = { showDialog = false }) { Text("Отмена") }
                }
            },
        )
    }
}

@Composable
private fun CatalogRow(item: CatalogItem, inLibrary: Boolean, downloading: Boolean, onDownload: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(item.name)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        listOf(typeLabel(item.fileName), item.version.takeIf { it.isNotBlank() }?.let { "v$it" })
                            .filterNotNull().joinToString(" · "),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(8.dp))
                when {
                    inLibrary -> Chip("Скачано", Ok)
                    downloading -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    else -> Button(onClick = onDownload, shape = RoundedCornerShape(12.dp)) { Text("Скачать") }
                }
            }
            if (item.description.isNotBlank()) {
                Text(item.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun Avatar(name: String) {
    Box(
        Modifier.size(44.dp).background(Violet.copy(alpha = 0.2f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(name.firstOrNull()?.uppercase() ?: "?", color = Violet, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun typeLabel(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
    "mcpack" -> "Пак"
    "mcaddon" -> "Аддон"
    "mcworld" -> "Мир"
    "mctemplate" -> "Шаблон мира"
    else -> "Файл"
}

private fun typeLabel(file: File): String = typeLabel(file.name)

private fun formatSize(bytes: Long): String =
    if (bytes < 1024 * 1024) "${bytes / 1024 + 1} КБ" else "%.1f МБ".format(bytes / 1048576.0)
