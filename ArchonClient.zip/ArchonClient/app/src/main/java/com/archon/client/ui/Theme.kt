package com.archon.client.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Violet = Color(0xFF8B5CF6)
val Bg = Color(0xFF0E0B16)
val Ok = Color(0xFF34D399)
val Warn = Color(0xFFF59E0B)

private val ArchonColors = darkColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    background = Bg,
    onBackground = Color(0xFFEDE9FE),
    surface = Color(0xFF181325),
    onSurface = Color(0xFFEDE9FE),
    surfaceVariant = Color(0xFF221B33),
    onSurfaceVariant = Color(0xFFA8A1BD),
    secondaryContainer = Color(0xFF3B2A66),
    onSecondaryContainer = Color.White,
)

@Composable
fun ArchonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ArchonColors, content = content)
}
