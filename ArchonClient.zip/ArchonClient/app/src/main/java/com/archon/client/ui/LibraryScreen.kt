package com.archon.client.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.archon.client.mods.InstallQueue
import com.archon.client.mods.ModBundler
import com.archon.client.mods.ModInstaller
import com.archon.client.mods.ModKind
import com.archon.client.mods.ModMeta
import com.archon.client.mods.ModsRepository
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun LibraryScreen(kind: ModKind, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refresh by remember { mutableIntStateOf(0) }
    val files = remember(refresh) { ModsRepository.list(context, kind) }
    val selected = remember { mutableStateListOf<String>() }
    var working by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<File?>(null) }

    // Если файл удалили, убираем его из выбранных
    LaunchedEffect(files) { selected.removeAll { name -> files.none { it.name == name } } }

    fun doDelete(f: File) {
        ModsRepository.delete(context, f)
        selected.remove(f.name)
        refresh++
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        scope.launch {
            val (added, skipped) = withContext(Dispatchers.IO) {
                var a = 0
                var s = 0
                uris.forEach { uri ->
                    if (runCatching { ModsRepository.importFromUri(context, uri, kind) }.getOrDefault(false)) a++ else s++
                }
                a to s
            }
            val msg = if (skipped == 0) "Добавлено: $added"
            else "Добавлено: $added, пропущено: $skipped (нужны ${kind.exts.joinToString { ".$it" }})"
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            refresh++
        }
    }

    fun installSelected() {
        val chosen = files.filter { it.name in selected }
        if (chosen.isEmpty() || working) return
        working = true
        scope.launch {
            val plan = withContext(Dispatchers.IO) { runCatching { ModBundler.plan(context, chosen) } }
            working = false
            plan.onSuccess { list ->
                val packs = chosen.count { ModBundler.isPack(it) }
                if (packs >= 2) {
                    Toast.makeText(context, "$packs аддонов собраны в один файл. Minecraft поставит их разом", Toast.LENGTH_LONG).show()
                }
                selected.clear()
                InstallQueue.start(context, list)
            }.onFailure {
                Toast.makeText(context, "Не удалось подготовить файлы: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)) {
            Text(
                "${kind.title} (${files.size})",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            Text(
                if (kind == ModKind.Addons) "Отметь несколько и поставь в Minecraft за один раз"
                else "Миры ставятся по очереди: после каждого вернись в Archon",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        QueueBanner()

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(14.dp)) {
                Text("+ Добавить")
            }
            Spacer(Modifier.weight(1f))
            if (files.isNotEmpty()) {
                val all = selected.size == files.size
                TextButton(onClick = {
                    selected.clear()
                    if (!all) selected.addAll(files.map { it.name })
                }) { Text(if (all) "Снять выбор" else "Выбрать все") }
            }
        }

        if (files.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Здесь пока пусто", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Нажми «+ Добавить» и выбери файлы с телефона (${kind.exts.joinToString { ".$it" }}).",
                    modifier = Modifier.padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(files, key = { it.name }) { file ->
                    val checked = file.name in selected
                    LibraryRow(
                        file = file,
                        checked = checked,
                        onToggle = { if (checked) selected.remove(file.name) else selected.add(file.name) },
                        onShare = { ModInstaller.share(context, file) },
                        onDelete = { if (AppSettings.confirmDelete) toDelete = file else doDelete(file) },
                    )
                }
            }
        }

        if (selected.isNotEmpty()) {
            Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
                Button(
                    onClick = { installSelected() },
                    enabled = !working,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                ) {
                    Text(
                        if (working) "Подготовка…" else "Установить в Minecraft (${selected.size})",
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }

    toDelete?.let { f ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить файл?") },
            text = { Text(f.nameWithoutExtension) },
            confirmButton = { TextButton(onClick = { doDelete(f); toDelete = null }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } },
        )
    }
}

@Composable
internal fun QueueBanner() {
    val context = LocalContext.current
    val left = InstallQueue.pending.size
    if (left > 0) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("В очереди ещё файлов: $left", fontWeight = FontWeight.Bold)
                Text(
                    "Minecraft принимает миры и шаблоны по одному. После импорта вернись в Archon и нажми «Следующий».",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { InstallQueue.next(context) }) { Text("Следующий") }
                    TextButton(onClick = { InstallQueue.cancel() }) { Text("Отмена") }
                }
            }
        }
    }
}

@Composable
private fun LibraryRow(
    file: File,
    checked: Boolean,
    onToggle: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(16.dp)
    var menu by remember { mutableStateOf(false) }
    val info by produceState<ModMeta.Info?>(null, file, file.lastModified()) {
        value = withContext(Dispatchers.IO) { runCatching { ModMeta.load(context, file) }.getOrNull() }
    }
    val title = info?.title ?: file.nameWithoutExtension
    val desc = info?.description.orEmpty()

    Card(
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (checked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        ),
        border = if (checked) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onToggle),
    ) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Thumb(info?.image, title, 52.dp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (desc.isNotBlank()) {
                    Text(
                        desc,
                        fontSize = 12.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Text(
                    "${typeLabel(file.name)} · ${formatSize(file.length())}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Меню") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Поделиться") }, onClick = { menu = false; onShare() })
                    DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun Thumb(image: File?, name: String, size: Dp) {
    if (image != null) {
        AsyncImage(
            model = image,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(RoundedCornerShape(12.dp)),
        )
    } else {
        val primary = MaterialTheme.colorScheme.primary
        Box(
            Modifier.size(size).background(primary.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(name.firstOrNull()?.uppercase() ?: "?", color = primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
internal fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

internal fun typeLabel(fileName: String): String = when (fileName.substringAfterLast('.', "").lowercase()) {
    "mcpack" -> "Пак"
    "mcaddon" -> "Аддон"
    "mcworld" -> "Мир"
    "mctemplate" -> "Шаблон мира"
    else -> "Файл"
}

internal fun formatSize(bytes: Long): String =
    if (bytes < 1024 * 1024) "${bytes / 1024 + 1} КБ" else "%.1f МБ".format(bytes / 1048576.0)
