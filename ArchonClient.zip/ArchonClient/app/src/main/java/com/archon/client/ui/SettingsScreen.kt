package com.archon.client.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.minecraft.MinecraftLauncher
import com.archon.client.mods.ModsRepository
import com.archon.client.settings.AppSettings

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var sourceUrl by remember { mutableStateOf(ModsRepository.getCatalogUrl(context)) }
    var showSource by remember { mutableStateOf(false) }

    @Suppress("DEPRECATION")
    val version = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        SettingsCard("Оформление") {
            Text("Цвет акцента", fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppSettings.accents.forEachIndexed { i, (_, color) ->
                    ColorDot(color, selected = i == AppSettings.accentIndex) { AppSettings.setAccent(context, i) }
                }
            }
            SwitchRow("Чёрный фон (AMOLED)", "Экономит заряд на OLED-экранах", AppSettings.amoled) {
                AppSettings.setAmoled(context, it)
            }
        }

        SettingsCard("Библиотека") {
            SwitchRow("Спрашивать перед удалением", null, AppSettings.confirmDelete) {
                AppSettings.setConfirmDelete(context, it)
            }
        }

        SettingsCard("Каталог") {
            Text(
                sourceUrl,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row {
                TextButton(onClick = { showSource = true }) { Text("Изменить источник") }
                TextButton(onClick = {
                    ModsRepository.setCatalogUrl(context, ModsRepository.DEFAULT_CATALOG_URL)
                    sourceUrl = ModsRepository.DEFAULT_CATALOG_URL
                }) { Text("По умолчанию") }
            }
        }

        SettingsCard("О приложении") {
            Text("Archon Client $version", fontWeight = FontWeight.Medium)
            Text(
                "Поддерживаемые версии Minecraft: до ${MinecraftLauncher.MAX_MAJOR}.${MinecraftLauncher.MAX_MINOR} включительно",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (showSource) {
        var text by remember { mutableStateOf(sourceUrl) }
        AlertDialog(
            onDismissRequest = { showSource = false },
            title = { Text("Источник каталога") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Ссылка на catalog.json") },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val u = text.trim()
                    if (u.startsWith("https://")) {
                        ModsRepository.setCatalogUrl(context, u)
                        sourceUrl = u
                        showSource = false
                    } else {
                        Toast.makeText(context, "Ссылка должна начинаться с https://", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showSource = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                title.uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.primary,
            )
            content()
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 15.sp)
            if (subtitle != null) {
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(color)
            .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
            .clickable(onClick = onClick),
    )
}
