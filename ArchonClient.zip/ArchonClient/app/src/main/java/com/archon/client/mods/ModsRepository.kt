package com.archon.client.mods

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class CatalogItem(
    val name: String,
    val description: String,
    val version: String,
    val url: String,
    val fileName: String,
)

object ModsRepository {
    const val DEFAULT_CATALOG_URL =
        "https://raw.githubusercontent.com/votintsevamin7-coder/archon-client/main/catalog.json"

    private val ALLOWED = setOf("mcpack", "mcaddon", "mcworld", "mctemplate")
    private const val PREFS = "archon"
    private const val KEY_URL = "catalog_url"

    fun isAllowed(name: String) = name.substringAfterLast('.', "").lowercase() in ALLOWED

    fun modsDir(context: Context): File = File(context.filesDir, "mods").also { it.mkdirs() }

    fun list(context: Context): List<File> =
        modsDir(context)
            .listFiles { f -> f.isFile && isAllowed(f.name) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun getCatalogUrl(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_URL, null) ?: DEFAULT_CATALOG_URL

    fun setCatalogUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_URL, url).apply()
    }

    fun friendly(e: Throwable): String = when (e) {
        is UnknownHostException -> "нет интернета или GitHub недоступен"
        is SocketTimeoutException -> "время ожидания истекло, попробуй ещё раз"
        is JSONException -> "catalog.json написан с ошибкой (проверь запятые и кавычки)"
        is IOException -> e.message ?: "ошибка сети"
        else -> e.message ?: e.javaClass.simpleName
    }

    /** Копирует выбранный пользователем файл в библиотеку приложения. */
    fun importFromUri(context: Context, uri: Uri): Boolean {
        val name = File(displayName(context, uri) ?: return false).name
        if (!isAllowed(name)) return false
        val dest = File(modsDir(context), name)
        val input = context.contentResolver.openInputStream(uri) ?: return false
        input.use { src -> dest.outputStream().use { src.copyTo(it) } }
        return true
    }

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun open(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", "ArchonClient/0.3")
        return conn
    }

    fun fetchCatalog(catalogUrl: String): List<CatalogItem> {
        // Параметр в конце ссылки нужен, чтобы GitHub не отдавал старую копию списка
        val fresh = if (catalogUrl.contains("?")) catalogUrl else "$catalogUrl?t=${System.currentTimeMillis()}"
        val conn = open(fresh)
        try {
            val code = conn.responseCode
            if (code == 404) throw IOException("каталог не найден (404): проверь, что файл catalog.json лежит в репозитории")
            if (code != 200) throw IOException("ошибка сервера: $code")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(text).getJSONArray("mods")
            val base = catalogUrl.substringBeforeLast('/') + "/"
            val result = mutableListOf<CatalogItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val file = o.optString("file")
                val url = o.optString("url").ifBlank {
                    if (file.isBlank()) "" else base + Uri.encode(file, "/")
                }
                if (url.isBlank()) continue
                val fileName = (if (file.isNotBlank()) file else Uri.parse(url).lastPathSegment ?: "")
                    .substringAfterLast('/')
                if (!isAllowed(fileName)) continue
                result += CatalogItem(
                    name = o.optString("name").ifBlank { fileName.substringBeforeLast('.') },
                    description = o.optString("description"),
                    version = o.optString("version"),
                    url = url,
                    fileName = fileName,
                )
            }
            return result
        } finally {
            conn.disconnect()
        }
    }

    fun download(context: Context, item: CatalogItem): File {
        val dir = modsDir(context)
        val dest = File(dir, File(item.fileName).name)
        val tmp = File(dir, dest.name + ".part")
        val conn = open(item.url)
        try {
            val code = conn.responseCode
            if (code == 404) {
                throw IOException(
                    "файл не найден в репозитории (404). Имя в catalog.json должно совпадать с файлом буква в букву: ${item.fileName}"
                )
            }
            if (code != 200) throw IOException("ошибка сервера: $code")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (!looksLikeZip(tmp)) throw IOException("скачался не файл мода (проверь ссылку и имя файла)")
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("не удалось сохранить файл")
            return dest
        } finally {
            conn.disconnect()
            tmp.delete()
        }
    }

    private fun looksLikeZip(f: File): Boolean =
        f.inputStream().use { it.read() == 'P'.code && it.read() == 'K'.code }
}
