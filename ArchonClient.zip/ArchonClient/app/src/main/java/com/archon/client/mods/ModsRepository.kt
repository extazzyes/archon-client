package com.archon.client.mods

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class CatalogItem(
    val name: String,
    val description: String,
    val version: String,
    val url: String,
    val fileName: String,
)

object ModsRepository {
    const val DEFAULT_CATALOG_URL =
        "https://raw.githubusercontent.com/votintsevamin7-coder/archon-client/main/catalog.json"

    private val ALLOWED = setOf("mcpack", "mcaddon", "mcworld", "mctemplate")
    private const val PREFS = "archon"
    private const val KEY_URL = "catalog_url"

    fun isAllowed(name: String) = name.substringAfterLast('.', "").lowercase() in ALLOWED

    fun modsDir(context: Context): File = File(context.filesDir, "mods").also { it.mkdirs() }

    fun list(context: Context): List<File> =
        modsDir(context)
            .listFiles { f -> f.isFile && isAllowed(f.name) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun getCatalogUrl(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_URL, null) ?: DEFAULT_CATALOG_URL

    fun setCatalogUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_URL, url).apply()
    }

    /** Копирует выбранный пользователем файл в библиотеку приложения. */
    fun importFromUri(context: Context, uri: Uri): Boolean {
        val name = File(displayName(context, uri) ?: return false).name
        if (!isAllowed(name)) return false
        val dest = File(modsDir(context), name)
        val input = context.contentResolver.openInputStream(uri) ?: return false
        input.use { src -> dest.outputStream().use { src.copyTo(it) } }
        return true
    }

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    fun fetchCatalog(catalogUrl: String): List<CatalogItem> {
        val conn = URL(catalogUrl).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        try {
            if (conn.responseCode != 200) throw IOException("Каталог не найден (код ${conn.responseCode})")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(text).getJSONArray("mods")
            val base = catalogUrl.substringBeforeLast('/') + "/"
            val result = mutableListOf<CatalogItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val file = o.optString("file")
                val url = o.optString("url").ifBlank {
                    if (file.isBlank()) "" else base + Uri.encode(file, "/")
                }
                if (url.isBlank()) continue
                val fileName = (if (file.isNotBlank()) file else Uri.parse(url).lastPathSegment ?: "")
                    .substringAfterLast('/')
                if (!isAllowed(fileName)) continue
                result += CatalogItem(
                    name = o.optString("name").ifBlank { fileName.substringBeforeLast('.') },
                    description = o.optString("description"),
                    version = o.optString("version"),
                    url = url,
                    fileName = fileName,
                )
            }
            return result
        } finally {
            conn.disconnect()
        }
    }

    fun download(context: Context, item: CatalogItem): File {
        val dir = modsDir(context)
        val dest = File(dir, File(item.fileName).name)
        val tmp = File(dir, dest.name + ".part")
        val conn = URL(item.url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        try {
            if (conn.responseCode != 200) throw IOException("Ошибка скачивания (код ${conn.responseCode})")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Не удалось сохранить файл")
            return dest
        } finally {
            conn.disconnect()
            tmp.delete()
        }
    }
}
